Ext.define("TTMobile.HuaMao.minivip.profile.Mobile", {
	extend: "Ext.app.Profile",
	views: [
		"TApi.view.XContent",
		"MiniVip.view.mobile.VNavigatorBar",
		"MiniVip.HuaMao.view.VHome", "MiniVip.HuaMao.view.VNotice",
		"MiniVip.HuaMao.view.VGrouponList", "MiniVip.HuaMao.view.VGrouponDetail", "MiniVip.HuaMao.view.VGrouponPay", "MiniVip.HuaMao.view.VPayResult",
		"MiniVip.HuaMao.view.VStoreList", "MiniVip.HuaMao.view.VStoreDetail", "MiniVip.HuaMao.view.VStoreLocation",
		"MiniVip.HuaMao.view.VActivityList", "MiniVip.HuaMao.view.VActivityDetail",
		"MiniVip.HuaMao.view.VVipAuthorize", "MiniVip.HuaMao.view.VModifyMobile",
		"MiniVip.HuaMao.view.VBonusItemList", "MiniVip.HuaMao.view.VBonusItemDetail",
		"MiniVip.HuaMao.view.VPark", "MiniVip.HuaMao.view.VParkAddLicense", "MiniVip.HuaMao.view.VParkRecord", "MiniVip.HuaMao.view.VParkPay", "MiniVip.HuaMao.view.VParkCoupon",
		"MiniVip.HuaMao.view.VUser", "MiniVip.HuaMao.view.VUserCenter", "MiniVip.HuaMao.view.VUserInfo",
		"MiniVip.HuaMao.view.VBonus", "MiniVip.HuaMao.view.VCoupon", "MiniVip.HuaMao.view.VCouponDetail", "MiniVip.HuaMao.view.VCollect",
		"MiniVip.HuaMao.view.VFeedback", "MiniVip.HuaMao.view.VRecharge", "MiniVip.HuaMao.view.VSign", "MiniVip.HuaMao.view.VAbout",
		"MiniVip.HuaMao.view.VComment", "MiniVip.HuaMao.view.VCommentList",
		"MiniVip.HuaMao.view.VGames", "MiniVip.HuaMao.view.VRoulettle", "MiniVip.HuaMao.view.VScratchCard"
	],
	isActive: function()
	{
		return true;
	},
	launch: function()
	{
		VNavigatorBar.init();
		AppContext.viewport.on({
			activeitemchange: function(view, newItem, oldItem)
			{
				//after animate
				VNavigatorBar.updateButtons();
				TApi.Popup.close();
			},
			delay: 300
		});
	}
});