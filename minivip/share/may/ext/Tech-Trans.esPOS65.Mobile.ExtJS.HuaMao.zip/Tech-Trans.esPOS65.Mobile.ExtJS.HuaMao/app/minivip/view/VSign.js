Ext.define("MiniVip.HuaMao.view.VSign", {
	extend : "XContainer",
	config: {
		module: PosServicePath.CONTENT_SIGN
	}
});
