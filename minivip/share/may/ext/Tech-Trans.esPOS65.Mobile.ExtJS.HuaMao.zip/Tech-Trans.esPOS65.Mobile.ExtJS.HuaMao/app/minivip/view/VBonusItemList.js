Ext.define("MiniVip.HuaMao.view.VBonusItemList", {
	extend : "XContainer",
	config: {
		module: PosServicePath.WEBCONTENT_BONUSITEMLIST
	}
});
