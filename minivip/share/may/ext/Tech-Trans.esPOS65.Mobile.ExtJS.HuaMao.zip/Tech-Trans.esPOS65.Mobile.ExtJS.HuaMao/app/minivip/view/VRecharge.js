Ext.define("MiniVip.HuaMao.view.VRecharge", {
	extend : "XContainer",
	config: {
		module: PosServicePath.CONTENT_RECHARGE
	}
});
