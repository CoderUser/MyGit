Ext.define("MiniVip.HuaMao.view.VStoreLocation", {
	extend : "XContainer",
	config: {
		module: PosServicePath.CONTENT_STORELOCATION
	}
});
