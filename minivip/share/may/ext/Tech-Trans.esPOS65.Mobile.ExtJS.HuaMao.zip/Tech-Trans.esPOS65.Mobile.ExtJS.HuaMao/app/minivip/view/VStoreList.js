Ext.define("MiniVip.HuaMao.view.VStoreList", {
	extend : "XContainer",
	isGet : false,
	config: {
		scrollable: null,
		beforeShow: function()
		{
			var me = this;
			return me.checkLogin(function(vipcode)
			{
				me.setJsonData({
					vip: vipcode,
					mallOrgId: MallUtil.getMallOrgId(),
					store: TApi.store.getStoreCode()
				});
				me.setModule(PosServicePath.CONTENT_STORELIST);
			});
		}
	}
});
