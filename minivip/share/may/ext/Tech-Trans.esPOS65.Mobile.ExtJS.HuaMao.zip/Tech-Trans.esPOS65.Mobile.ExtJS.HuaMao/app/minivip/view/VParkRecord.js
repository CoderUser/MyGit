Ext.define("MiniVip.HuaMao.view.VParkRecord", {
	extend : "XContainer",
	config: {
		module: PosServicePath.CONTENT_PARKRECORD
	}
});
