Ext.define("MiniVip.HuaMao.view.VHome", {
	extend : "XContainer",
	config: {
		scrollable: {
			direction: "vertical",
			directionLock: true,
			indicators: true
		}
	},
	initialize: function()
	{
		this.callParent();
		// var vipCode = TApi.vip.getVipCode();
		// var requestData = {
		// 	store: TApi.store.getStoreCode()
		// };
		// if (vipCode) requestData.vip = vipCode;
		// this.setJsonData(requestData);
		this.setModule(PosServicePath.WEBCONTENT_HOME);
	}
});
