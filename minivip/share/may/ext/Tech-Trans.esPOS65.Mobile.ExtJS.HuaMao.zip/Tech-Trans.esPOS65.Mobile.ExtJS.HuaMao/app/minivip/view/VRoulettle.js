Ext.define("MiniVip.HuaMao.view.VRoulettle", {
	extend: "XContainer",
	config: {
		beforeShow: function()
		{
			var me = this;
			return me.checkLogin(function(vipcode)
			{
				me.setJsonData({
					vip: vipcode,
					store: TApi.store.getStoreCode()
				});
				me.setModule(PosServicePath.CONTENT_ROULETTLE);
			});
		}
	}
});
