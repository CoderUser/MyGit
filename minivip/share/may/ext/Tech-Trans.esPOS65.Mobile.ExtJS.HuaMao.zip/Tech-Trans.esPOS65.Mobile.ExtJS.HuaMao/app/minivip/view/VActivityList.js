Ext.define("MiniVip.HuaMao.view.VActivityList", {
	extend: "XContainer",
	config: {
		beforeShow: function()
		{
			var me = this;
			// return me.checkLogin(function(vipcode)
			// {
				me.setJsonData({
					vip: TApi.vip.getVipCode()
				});
				me.setModule(PosServicePath.WEBCONTENT_ACTIVITYLIST);
			// });
		}
	}
});
