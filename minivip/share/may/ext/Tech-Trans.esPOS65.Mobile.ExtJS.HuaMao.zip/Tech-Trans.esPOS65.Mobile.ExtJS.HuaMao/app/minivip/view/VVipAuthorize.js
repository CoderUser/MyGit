Ext.define("MiniVip.HuaMao.view.VVipAuthorize", {
	extend: "XContainer",
	constructor: function (config)
	{
		this.callParent(arguments);
		//init view
		this.setJsonData({
			mediaType: AppContext.getMediaType(),
			mediaId: AppContext.getConfig("mediaId")
		});
		if (config.param == "register")
		{
			if (TApi.vip.checkLogin())
			{
				TApi.Toast.show(Localize.getLangValue("AlreadyRegister"));
				location.hash = "VUser";
			}
			else
			{
				this.setModule(PosServicePath.CONTENT_REGISTER);
			}
		}
		else if (config.param == "reset")
		{
			this.setModule(PosServicePath.CONTENT_MODIFYPWD);
		}
	}
});
