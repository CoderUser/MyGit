Ext.define("MiniVip.HuaMao.view.VNotice", {
	extend : "XContainer",
	config: {
		module: PosServicePath.CONTENT_NOTICE
	}
});
