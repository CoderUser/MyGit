Ext.define("MiniVip.HuaMao.view.VUserCenter", {
	extend : "XContainer",
	config: {
		module: PosServicePath.WEBCONTENT_USERCENTER
	}
});
