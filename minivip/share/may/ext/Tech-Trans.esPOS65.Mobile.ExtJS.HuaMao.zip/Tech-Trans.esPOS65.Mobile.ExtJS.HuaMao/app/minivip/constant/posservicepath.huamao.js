window.PosServicePath = Object.create(window.PosServicePath || null, function()
{
	var BRANCH_WEB = "web",
		BRANCH_HUAMAO = "huamao/minivip";
	var VERSION = "V65";
	var MOBILE_CONTENT = BRANCH_WEB + "/content" + VERSION,
		MINIVIP_CONTENT = BRANCH_HUAMAO + "/webcontent" + VERSION,
		MINIVIP_VIP = BRANCH_HUAMAO + "/vip" + VERSION;


	var getPathGetModule = function(module, footerModule)
	{
		var path = MINIVIP_CONTENT + "/getmodule?module=" + module;
		if (footerModule) path += "&ftmodule=" + footerModule;
		return path;
	};

	return {
		WEBCONTENT_HOME: {value: MINIVIP_CONTENT + "/home"},
		CONTENT_NOTICE: {get: function() {return getPathGetModule("notice")}},

		CONTENT_GROUPON: {get: function() {return getPathGetModule("groupon")}},
		CONTENT_GROUPONDETAIL: {value: MINIVIP_CONTENT + "/groupondetail"},
		CONTENT_GROUPONPAY: {get: function() {return getPathGetModule("grouponpay")}},
		CONTENT_PAYRESULT: {get: function() {return getPathGetModule("payresult")}},

		WEBCONTENT_LOGIN: {get: function() {return getPathGetModule("login")}},
		CONTENT_REGISTER: {get: function() {return getPathGetModule("register")}},
		CONTENT_MODIFYPWD: {get: function() {return getPathGetModule("modifypwd")}},
		CONTENT_MODIFYMOBILE: {value: MINIVIP_CONTENT + "/telphone"},

		WEBCONTENT_USER: {value: MINIVIP_CONTENT + "/mypage"},
		WEBCONTENT_USERCENTER: {get: function() {return getPathGetModule("usercenter")}},
		CONTENT_VIPINFO: {value: MINIVIP_CONTENT + "/myinfo"},
		WEBCONTENT_BONUS: {value: MINIVIP_CONTENT + "/bonusledger"},
		WEBCONTENT_COLLECT: {value: MINIVIP_CONTENT + "/mycollect"},
		WEBCONTENT_COUPON: {get: function() {return getPathGetModule("coupon")}},
		WEBCONTENT_COUPONDETAIL: {get: function() {return getPathGetModule("coupondetail")}},
		WEBCONTENT_ABOUT: {get: function() {return getPathGetModule("about")}},
		WEBCONTENT_FEEDBACK: {get: function() {return getPathGetModule("feedback")}},
		CONTENT_RECHARGE: {get: function() {return getPathGetModule("recharge")}},
		CONTENT_SIGN: {get: function() {return getPathGetModule("sign")}},

		WEBCONTENT_COMMENT: {get: function() {return getPathGetModule("comment")}},
		WEBCONTENT_COMMENTLIST: {get: function() {return getPathGetModule("commentlist")}},

		WEBCONTENT_ACTIVITYLIST: {value: MINIVIP_CONTENT + "/campaignlist"},
		WEBCONTENT_ACTIVITYDETAIL: {value: MINIVIP_CONTENT + "/campaigndetail"},

		WEBCONTENT_BONUSITEMLIST: {get: function() {return getPathGetModule("bonusitemlist")}},
		WEBCONTENT_BONUSITEMDETAIL: {get: function() {return getPathGetModule("bonusitemdetail")}},

		CONTENT_STORELIST: {value: MINIVIP_CONTENT + "/mallguidecriteria"},
		CONTENT_STOREDETAIL: {get: function() {return getPathGetModule("storedetail")}},
		CONTENT_STORELOCATION: {get: function() {return getPathGetModule("storelocation")}},

		CONTENT_PARK: {get: function() {return getPathGetModule("park")}},
		CONTENT_PARKADDLICENSE: {get: function() {return getPathGetModule("parkaddlicense")}},
		CONTENT_PARKRECORD: {get: function() {return getPathGetModule("parkrecord")}},
		CONTENT_PARKPAY: {get: function() {return getPathGetModule("parkpay")}},
		CONTENT_PARKCOUPON: {get: function() {return getPathGetModule("parkcoupon")}},

		CONTENT_GAMES: {get: function() {return getPathGetModule("games")}},
		CONTENT_ROULETTLE: {get: function() {return getPathGetModule("roulette")}},
		CONTENT_SCRATCHCARD: {get: function() {return getPathGetModule("scratchcard")}},

		//request
		CONTENT_GROUPONLISTDETAIL : {value: MINIVIP_CONTENT + "/grouponlist"},
		CONTENT_STORELISTDETAIL: {value: MINIVIP_CONTENT + "/mallguidedetail"}

	}
}());