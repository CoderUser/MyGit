Ext.define("MiniVip.HuaMao.view.VGrouponDetail", {
	extend : "XContainer",
	config: {
		beforeShow: function()
		{
			var me = this;
			return me.checkLogin(function(vipcode)
			{
				me.setJsonData({
					vip: vipcode,
					mallOrgId: MallUtil.getMallOrgId(),
					cp: me.param
				});
				me.setModule(PosServicePath.CONTENT_GROUPONDETAIL);
			});
		}
	}
});
