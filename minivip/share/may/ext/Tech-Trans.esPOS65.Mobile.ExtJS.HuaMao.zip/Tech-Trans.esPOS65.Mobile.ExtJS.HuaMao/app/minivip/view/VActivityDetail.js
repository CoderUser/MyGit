Ext.define("MiniVip.HuaMao.view.VActivityDetail", {
	extend: "XContainer",
	config: {
		beforeShow: function()
		{
			var me = this;
			return me.checkLogin(function(vipcode)
			{
				me.setJsonData({
					vip: vipcode,
					cp: me.param
				});
				me.setModule(PosServicePath.WEBCONTENT_ACTIVITYDETAIL);
			});
		}
	}
});
