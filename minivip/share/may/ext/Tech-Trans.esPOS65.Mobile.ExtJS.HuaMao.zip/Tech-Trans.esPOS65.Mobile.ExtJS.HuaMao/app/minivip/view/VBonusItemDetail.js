Ext.define("MiniVip.HuaMao.view.VBonusItemDetail", {
	extend : "XContainer",
	config: {
		module: PosServicePath.WEBCONTENT_BONUSITEMDETAIL
	}
});
