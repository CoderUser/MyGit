// ------------------------------------------------------- Validator -------------------------------------------------------
window.Validator = (function(_validator)
{
	_validator.checkTel = function(value)
	{
		//check china & hong kong telephone
		return (/^1[3-8]\d{9}$/i.test(value) || /^[5-9]\d{7}$/i.test(value));
	};
	return _validator;
})(window.Validator || {});

// ------------------------------------------------------- vip -------------------------------------------------------
window.TApi.vip = (function(_TApi)
{
	var _vip = _TApi.vip || {};

	return _vip;
})(window.TApi || {});