Ext.define("MiniVip.HuaMao.view.VStoreDetail", {
	extend : "XContainer",
	config: {
		module: PosServicePath.CONTENT_STOREDETAIL
	}
});
