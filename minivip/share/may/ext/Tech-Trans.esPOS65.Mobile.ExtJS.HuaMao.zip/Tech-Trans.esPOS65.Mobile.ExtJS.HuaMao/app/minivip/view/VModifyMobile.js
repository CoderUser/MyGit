Ext.define("MiniVip.HuaMao.view.VModifyMobile", {
	extend : "XContainer",
	config: {
		beforeShow: function()
		{
			var me = this;
			return me.checkLogin(function(vipcode)
			{
				me.setJsonData({
					vip: vipcode
				});
				me.setModule(PosServicePath.CONTENT_MODIFYMOBILE);
			});
		}
	}
});
