Ext.define("MiniVip.HuaMao.view.VUser", {
	extend : "XContainer",
	constructor: function(config)
	{
		this.callParent();
		var me = this;

		function gotoUser()
		{
			me.setJsonData({
				mediaType: AppContext.getMediaType(),
				mediaId: AppContext.getConfig("mediaId"),
				vip: TApi.vip.getVipCode(),
				store: TApi.store.getStoreCode()
			});
			me.setModule(PosServicePath.WEBCONTENT_USER);
		}

		function gotoLogin()
		{
			me.setJsonData({
				mediaType: AppContext.getMediaType(),
				mediaId: AppContext.getConfig("mediaId")
			});
			me.setModule(PosServicePath.WEBCONTENT_LOGIN);
		}

		if (config.param === "logout")
		{
			gotoLogin();
			return;
		}

		if (TApi.vip.getVipCode())
		{
			gotoUser();
		}
		else
		{
			var autoLogin = false;
			// wechat auto login
			if (TApi.Platform.isWechat() && AppContext.getMediaType() === TConstant.MEDIATYPE_WECHAT)
			{
				// not auto login if check logout flag
				if (TApi.Cookie.getCookie("logout") !== "1")
				{
					var openId = TApi.Wechat.getOpenId();
					if (openId)
					{
						autoLogin = true;
						// auto login if wechat bound
						TApi.vip.doLoginWechat(openId, function(success)
						{
							if (success)
								gotoUser();
							else
								gotoLogin();
						});
					}
				}
			}
			if (!autoLogin) gotoLogin();
		}
	}
});
