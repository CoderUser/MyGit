Ext.define("MiniVip.HuaMao.view.VParkCoupon", {
	extend : "XContainer",
	config: {
		beforeShow: function(message, oldItem, paramvalue)
		{
			var me = this;
			return me.checkLogin(function(vipcode)
			{
				VAddressList.selected = null;
				VAddressList.tabToClose = (paramvalue == "tc");
				me.setJsonData({
					vip: vipcode
				});
				TApi.Area.getArea();
				me.setModule(PosServicePath.CONTENT_PARKCOUPON);
			});
		}
	}
});
